# TOOFAN V2RAY — Installation Guide (বাংলা)

## ১. প্রয়োজনীয় VPS / server

Backend hosting-এর জন্য একটি Ubuntu 24.04 LTS VPS, public IPv4, root/sudo access, domain এবং TLS certificate লাগবে। ছোট পরীক্ষার জন্য 2 vCPU / 2–4 GB RAM ব্যবহার করা যায়; ব্যবহারকারী, log, traffic ও concurrent session বাড়লে capacity বাড়াতে হবে। VPN tunnel host করার VPS provider-এর লিখিত অনুমোদন আগে নিশ্চিত করুন।

PHP 8.2+ (সুপারিশ: 8.3/8.4), Composer 2, MySQL 8/MariaDB, Nginx, PHP extensions `bcmath`, `ctype`, `curl`, `fileinfo`, `mbstring`, `openssl`, `pdo_mysql`, `tokenizer`, `xml`, `zip` দরকার।

## ২. Backend deploy

1. ZIP extract করে `backend/` folder server-এ রাখুন; উদাহরণ `/var/www/toofan/backend`।
2. Backend folder-এ গিয়ে `composer install --no-dev --optimize-autoloader` চালান।
3. `.env.example` কপি করে `.env` বানান: `cp .env.example .env`।
4. `.env`-এ `APP_URL=https://আপনার-ডোমেইন`, MySQL database/user/password সেট করুন। `APP_DEBUG=false` রাখুন। Production-এ `SESSION_SECURE_COOKIE=true` রাখুন।
5. Database তৈরি করে MySQL user-কে শুধু ওই database-এ প্রয়োজনীয় permission দিন।
6. `php artisan key:generate` চালান।
7. `php artisan migrate --seed` চালান। এতে default plan (৩০ মিনিট, ৬০ মিনিট, ১ মাস, ২ মাস) তৈরি হবে। Plan-এর credit cost database-এর `plans` table-এ আছে; production-এ পরিবর্তনের আগে ব্যাকআপ নিন।
8. `php artisan app:create-admin` চালিয়ে Super Admin username ও অন্তত ১৪ অক্ষরের password দিন। কোনো default login নেই।
9. `php artisan optimize` চালান।
10. Web server-এর document root অবশ্যই `backend/public` হবে, `backend/` নয়।

Laravel local smoke check-এর জন্য `.env`-এ সাময়িক `APP_ENV=local`, `APP_DEBUG=true` এবং HTTP localhost হলে `SESSION_SECURE_COOKIE=false` করা যায়। Production-এ এগুলো পুনরায় secure setting-এ ফেরত দিন।

## ৩. Nginx site-এর মূল অংশ

```nginx
server {
    listen 80;
    server_name vpn.example.com;
    root /var/www/toofan/backend/public;
    index index.php;
    location / { try_files $uri $uri/ /index.php?$query_string; }
    location ~ \\.php$ {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    }
    location ~ /\\. { deny all; }
}
```

PHP-FPM socket path আপনার VPS-এর PHP version অনুযায়ী বদলাতে হবে। এরপর Certbot/আপনার certificate authority দিয়ে HTTPS চালু করুন। Firewall-এ কেবল প্রয়োজনীয় SSH, HTTP/HTTPS এবং VPN server-এর নির্দিষ্ট public port খুলুন; Xray management/control port public internet-এ উন্মুক্ত রাখবেন না।

## ৪. Admin/Reseller workflow

- Admin `/login` থেকে প্রবেশ করে `/resellers`-এ reseller তৈরি ও credit allocate করবেন।
- Reseller নিজের login থেকে child reseller তৈরি করতে পারবে, তবে নিজের credits যথেষ্ট থাকতে হবে।
- `/premium`-এ customer username/password ও plan বেছে account record তৈরি হবে। খরচ server-side balance check করে deduct হয়।
- `/bulk`-এ সর্বোচ্চ ৫০টি record একসঙ্গে তৈরি হয়; generated credentials শুধু creation response-এ দেখানো হয়। সেগুলো নিরাপদে সংরক্ষণ করুন।
- `/servers`-এ Admin server endpoint catalogue রাখতে পারবেন। Xray service তৈরি/পরীক্ষা না করে server-কে app-এ publish করবেন না। `/premium`-এর account row থেকে Super Admin `Set Xray config` খুলে ওই user-এর Xray client JSON paste করলে সেটি encryptedভাবে store হয়ে API config endpoint active হবে। Admin-only UUID column থেকে client UUID নিয়ে matching inbound-এ client manually add করুন। এরপর ওই client-এর জন্য তৈরি Xray JSON paste করুন। Panel remote server-এ auto-create/revoke করে না। Expiry/Block/Renew change হলে Xray server-এ user update/remove না করা পর্যন্ত পূর্বে imported profile চলতে পারে; automatic expiry/revocation adapter ছাড়া এটিকে production access control হিসেবে ধরে নেবেন না।
- `/logs`-এ activity এবং credit transaction দেখুন।

## ৫. Android client build

Android Studio-তে `android-client/` খুলুন। JDK 17 ও Android SDK 35 লাগবে। Backend HTTPS URL দিয়ে build করুন:

```bash
./gradlew assembleDebug -PAPI_BASE_URL=https://vpn.example.com/api/v1
```

এই starter-এ native Xray core নেই; তাই এটি account/login UI চালালেও VPN tunnel চালায় না। Xray integration-এর জন্য `XRAY_ANDROID_INTEGRATION_BN.md` পড়ুন।

## ৬. Credentials নিরাপত্তা

- Root SSH password, private key, database password বা Xray API secret কাউকে chat-এ পাঠাবেন না। নিজে server-এ `.env`/secret manager-এ রাখুন।
- Super Admin password password manager-এ রাখুন; আলাদা admin account ব্যবহার করুন।
- নিয়মিত database + Xray config backup, security updates, log retention এবং restore test করুন।
- Bulk credentials এবং one-time PIN কপি করে নিরাপদ channel-এ customer-কে দিন। Screenshot/public chat-এ credential দেবেন না।

## ৭. Production acceptance checklist

- [ ] HTTPS এবং secure cookie যাচাই
- [ ] Admin + reseller role isolation পরীক্ষা
- [ ] Zero-credit এবং insufficient-credit account creation reject পরীক্ষা
- [ ] Concurrent credit deduction/rollback পরীক্ষা
- [ ] Reseller child hierarchy/transfer scope পরীক্ষা
- [ ] API token expiry/logout পরীক্ষা
- [ ] Xray provisioning adapter ও real server health/expiry enforcement
- [ ] Android native Xray core এবং VPN permission/lifecycle test
- [ ] VPS provider written approval, backups, firewall ও monitoring

### বিকল্প: GitHub Actions দিয়ে Debug APK

এই package root-এ `.github/workflows/build-debug-apk.yml` আছে। পুরো `TOOFAN_V2RAY_COMPLETE/` folder একটি GitHub repository-র root-এ push করলে `main` branch-এ Android source পরিবর্তনে বা Actions থেকে `Build TOOFAN V2RAY debug APK` manually চালালে build workflow চলবে। GitHub repository Settings → Secrets and variables → Actions → Variables-এ `API_BASE_URL` নামে HTTPS API URL দিন। Workflow-র Artifacts থেকে `toofan-v2ray-debug-apk` সংগ্রহ করা যাবে। এটি debug APK; Play Store release-এর জন্য নিজের keystore দিয়ে signed release build আলাদাভাবে করতে হবে। Native Xray core না থাকায় debug APK-তেও VPN connect হবে না।
