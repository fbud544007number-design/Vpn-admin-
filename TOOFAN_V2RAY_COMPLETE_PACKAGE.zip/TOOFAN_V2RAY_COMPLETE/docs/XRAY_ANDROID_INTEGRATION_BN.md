# Xray / libXray Integration — বাংলা

এই starter-এর Backend account record ও Android API client প্রস্তুত; Xray server-এ VLESS client create/revoke এবং Android native tunnel engine এখনও সংযুক্ত নয়। বাস্তব Xray endpoint, credentials, public key/REALITY settings, server-side control channel বা libXray native artifact ছাড়া কার্যকর connection বানানো সম্ভব নয়।

## Android native core

Official wrapper repository: https://github.com/XTLS/libXray

বর্তমান official README অনুযায়ী libXray Android build-এর জন্য repository-এর build script ব্যবহার করে `python3 build/main.py android` চালাতে বলা হয়েছে; Android minimum API level 21, API entrypoint `Invoke(requestJSON string) string` এবং request schema-তে `apiVersion: 3` ব্যবহার হয়। Repository নিজেই API stability guarantee করে না এবং maintainer support সীমিত বলে সতর্ক করে। তাই release/version pin করে নিজের test suite রাখা জরুরি।

সম্ভাব্য integration sequence:

1. নিরাপদ development machine-এ official libXray source checkout করুন এবং README-এর dependency অনুযায়ী Go, Python, gomobile/toolchain প্রস্তুত করুন।
2. Official build script দিয়ে Android artifact build করুন। Build output আপনার checked-out commit/version অনুযায়ী যাচাই করুন।
3. `android-client/app`-এ generated AAR/JNI libraries যোগ করুন; build output-এর actual package/API অনুসারে `XrayEngine` adapter implement করুন। এই ZIP-এ fabricated `.aar` বা binary রাখা হয়নি।
4. Android `VpnService` consent, TUN interface, socket protect callback, DNS resolver এবং service foreground lifecycle সঠিকভাবে implement করুন। libXray README-এর Android controller/socket-protect/DNS নির্দেশনা অনুসরণ করুন।
5. Backend থেকে authenticated, short-lived, account-bound Xray config retrieve করুন। Config-এ private server secrets app logs-এ লিখবেন না।
6. Connect/Disconnect, network handover, app background, device reboot, expired account, revoke, battery saver ও IPv4/IPv6 leak test করুন।

## Server-side provisioning

Backend এখন `vpn_accounts` row, unique `xray_client_id`, expiry ও status `pending_server_provisioning` রাখে। Production adapter-এ নিচের কাজগুলো transaction-safe background job হিসেবে করতে হবে:

- Xray server-এর authenticated/private management integration-এ unique client UUID add করা;
- `VLESS` inbound/transport/security profile অনুযায়ী client config তৈরি করা;
- expiry হওয়ার সময় client revoke/remove করা;
- server failure হলে retry, audit log এবং account status reconcile করা;
- config app-কে TLS-protected API-তে short-lived authorization দিয়ে দেওয়া;
- concurrent operation ও rollback/idempotency test করা।

Management port কখনো public unauthenticated endpoint করবেন না। SSH/API secret source code বা database-এর plaintext field-এ রাখবেন না; secret manager/environment ব্যবহার করুন।

## গুরুত্বপূর্ণ

Xray ব্যবহার করার জন্য device-এর বৈধ Wi-Fi/mobile data connection থাকতে হবে। এই setup কোনো carrier billing, free-data entitlement, APN loophole বা SIM data cap bypass করে না।

## Panel-এর Manual Config Flow

1. Admin Premium account তৈরি করবে। Account record-এ একটি unique `xray_client_id` (UUID) তৈরি হয়; UUID column শুধু Super Admin দেখতে পায়।
2. Admin এই UUID-কে নিজের অনুমোদিত Xray server-এর নির্দিষ্ট inbound-এ manually add করবে।
3. Matching user-এর client-side Xray JSON config নিয়ে Premium account row-এর `Set Xray config` form-এ paste করবে। Backend JSON-এ অন্তত একটি `outbounds` array আছে কিনা যাচাই করে config-টি Laravel encrypted cast দিয়ে database-এ রাখে এবং account API status `active` করে।
4. Android app user API login/activation-এর পর account config endpoint ব্যবহার করতে পারবে—তবে এই starter APK-তে native libXray engine না থাকায় tunnel চালু হবে না।
5. Block/expiry/revoke/renew হলে সংশ্লিষ্ট Xray inbound থেকে client manually disable/remove/update না করা পর্যন্ত পূর্বে imported config দিয়ে tunnel চলতে পারে। Production launch-এর আগে automatic server-side revoke/expiry synchronization বাধ্যতামূলকভাবে implement ও test করুন।
