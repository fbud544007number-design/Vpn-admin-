# Mobile API Reference

Base URL: `https://YOUR_DOMAIN/api/v1`

## POST `/auth/login`
Request: `{"username":"customer01","password":"..."}`
Response: bearer token, expiry and user role.

## POST `/auth/activate`
Request: `{"username":"customer01","pin":"ONE-TIME-PIN","new_password":"new-long-password"}`
One-time generated PIN hash-এর সঙ্গে মিললে password update করে token ফেরত দেয়; PIN দ্বিতীয়বার ব্যবহার করা যায় না।

## Authenticated endpoints
প্রতিটি request-এ `Authorization: Bearer <token>` দিতে হবে।

- `POST /auth/logout` — current token revoke
- `GET /me` — user role, credits, account expiry/status
- `GET /servers` — Admin-published active server catalogue
- `GET /accounts` — current user's account records
- `GET /accounts/{id}/config` — কেবল active, unexpired এবং provisioned config দেয়; provision না হলে HTTP 409

Login/activation API throttled। Bearer token database-এ raw হিসেবে নয়, SHA-256 hash হিসেবে সংরক্ষিত।
