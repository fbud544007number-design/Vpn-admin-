# TOOFAN V2RAY VPN — Complete Starter Package

আপনার দেওয়া **একই Toofan V2RAY গোল লোগো ও wordmark** অপরিবর্তিতভাবে `branding/` এবং Admin Panel/Android app asset-এ রাখা হয়েছে। ব্র্যান্ড নাম: **TOOFAN V2RAY**।

এই প্যাকেজে তিনটি কাজের অংশ আছে:

1. `backend/` — Laravel 12 ভিত্তিক Admin ও Reseller web panel এবং REST API source।
2. `android-client/` — native Kotlin Android client skeleton; HTTPS API login, encrypted token storage, account/server data fetch এবং Toofan branding।
3. `docs/` — বাংলা installation, API ও Xray integration নির্দেশিকা।

## এখন প্যাকেজে কী কাজ করে

- Web login: Super Admin এবং Reseller role আলাদা। Customer web panel-এ প্রবেশ করতে পারে না।
- Dashboard: account, reseller, credit summary, activity এবং recent account list।
- Reseller: Admin নতুন reseller খুলে initial credit দিতে পারে; Reseller নিজের balance থেকে sub-reseller তৈরি করতে পারে।
- Credit: insufficient/zero balance হলে customer account বা sub-reseller create server-side transaction-এর মধ্যে reject হয়।
- Premium: username/password, মেয়াদভিত্তিক plan, one-time activation PIN, block/unblock, renewal, transaction record ও account expiry। Admin-এর জন্য generated Xray client UUID দেখা যায় এবং matching Xray client JSON encryptedভাবে manually attach করা যায়।
- Bulk: সর্বোচ্চ ৫০টি account এক database transaction-এ; অপর্যাপ্ত credit হলে সব rollback।
- Activity/Credit logs: কে কখন কী করেছে তার audit record।
- Server catalogue: Admin server endpoint record করতে পারে এবং app-এ প্রকাশ করতে পারে। Admin প্রতি account-এর জন্য JSON Xray client profile paste করে encrypted storage-এ রেখে API config access activate করতে পারে; তবে এটি নিজে remote Xray server-এ user add/revoke করে না।
- Mobile API: login, one-time PIN activation, logout, current user, server list, account list এবং provisioned config endpoint। Bearer token database-এ SHA-256 hash হিসেবে রাখা হয়।
- Android UI: customer/reseller login, server list, account status/expiry display, logout এবং Keystore-encrypted API token।

## যেগুলো এখনও Live নয়

- Xray server-এ account স্বয়ংক্রিয় add/remove, expiry/block revoke, live session telemetry, traffic quota, server health check ও automatic config distribution adapter এখনও যুক্ত হয়নি। তাই নতুন account `pending_server_provisioning` অবস্থায় থাকবে; Admin matching Xray user manually set করে JSON config attach করলে API config endpoint active হবে। Expiry/block server-এ sync না হওয়া পর্যন্ত আগে থেকে imported/live config চলতে পারে।
- Android APK-তে libXray native core/AAR/JNI integration নেই। তাই Connect বোতাম disabled এবং কোনো VPN tunnel তৈরি করে না। এভাবে অসম্পূর্ণ tunnel-কে কাজ করছে বলে দেখানো হয়নি।
- এই runtime-এ Composer/Android SDK নেই; ফলে এখানে Laravel dependencies install, database migration, Android build বা signed APK তৈরি করে যাচাই করা যায়নি। PHP source-গুলোর `php -l` syntax check করা হয়েছে।
- Payment gateway, SMS/email, Play Store signing, production monitoring ও automated backups সংযুক্ত নয়।

## ইনস্টল শুরু

বাংলা নির্দেশিকা: `docs/INSTALL_BN.md`

## গুরুত্বপূর্ণ নিরাপত্তা ও বৈধ ব্যবহার

- প্রথম Admin নিজে `php artisan app:create-admin` দিয়ে তৈরি করবেন। কোনো default username/password রাখা হয়নি।
- Production-এ HTTPS, secure cookies, strong database password, firewall, backups এবং VPS provider-এর VPN/commercial resale policy অনুমোদন প্রয়োজন।
- VPN tunnel কেবল বিদ্যমান বৈধ internet connection ব্যবহার করে; এটি SIM data তৈরি করে না বা STC/Zain/Mobily/অন্য carrier-এর billing/data cap bypass করে না।
- Toofan logo/wordmark আপনার দেওয়া image। তৃতীয় পক্ষের trademark বা artwork বাণিজ্যিকভাবে ব্যবহার করার অধিকার/অনুমতি আছে কিনা নিশ্চিত করুন।
