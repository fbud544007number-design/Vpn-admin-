<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { public function up(): void { Schema::create('credit_transactions',function(Blueprint $t):void{$t->id();$t->foreignId('actor_id')->constrained('users');$t->foreignId('from_user_id')->nullable()->constrained('users')->nullOnDelete();$t->foreignId('to_user_id')->nullable()->constrained('users')->nullOnDelete();$t->unsignedBigInteger('amount');$t->string('kind',40)->index();$t->string('reference_type')->nullable();$t->unsignedBigInteger('reference_id')->nullable();$t->string('note')->nullable();$t->timestamps();$t->index(['reference_type','reference_id']);}); } public function down():void{Schema::dropIfExists('credit_transactions');} };
