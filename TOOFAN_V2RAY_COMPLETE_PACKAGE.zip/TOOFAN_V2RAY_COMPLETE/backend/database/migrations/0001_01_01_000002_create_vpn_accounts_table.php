<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { public function up(): void { Schema::create('vpn_accounts',function(Blueprint $t):void{$t->id();$t->foreignId('user_id')->constrained()->cascadeOnDelete();$t->foreignId('created_by')->constrained('users');$t->foreignId('plan_id')->nullable()->constrained()->nullOnDelete();$t->string('plan_name');$t->unsignedInteger('credits_cost');$t->timestamp('expires_at')->index();$t->string('status',40)->default('pending_server_provisioning')->index();$t->uuid('xray_client_id')->nullable()->unique();$t->text('config_json')->nullable();$t->timestamp('last_connected_at')->nullable();$t->timestamps();}); } public function down():void{Schema::dropIfExists('vpn_accounts');} };
