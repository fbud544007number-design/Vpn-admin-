<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { public function up(): void { Schema::create('plans',function(Blueprint $t):void{$t->id();$t->string('name');$t->unsignedInteger('duration_minutes');$t->unsignedInteger('credit_cost');$t->boolean('is_active')->default(true);$t->timestamps();}); } public function down():void{Schema::dropIfExists('plans');} };
