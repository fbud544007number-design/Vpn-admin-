<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { public function up(): void {
    Schema::create('vpn_servers',function(Blueprint $t):void{$t->id();$t->string('name');$t->string('country',80);$t->string('host');$t->unsignedSmallInteger('port');$t->string('protocol',24)->default('VLESS');$t->boolean('is_active')->default(false);$t->unsignedInteger('sort_order')->default(0);$t->timestamps();});
    Schema::create('api_tokens',function(Blueprint $t):void{$t->id();$t->foreignId('user_id')->constrained()->cascadeOnDelete();$t->char('token_hash',64)->unique();$t->timestamp('expires_at')->index();$t->timestamp('last_used_at')->nullable();$t->timestamps();});
} public function down():void{Schema::dropIfExists('api_tokens');Schema::dropIfExists('vpn_servers');} };
