<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void { Schema::create('users', function(Blueprint $table): void {
        $table->id(); $table->string('username',60)->unique(); $table->string('email')->nullable()->unique();
        $table->string('password'); $table->char('activation_pin_hash',64)->nullable(); $table->string('role',24)->default('customer')->index(); $table->foreignId('parent_id')->nullable()->constrained('users')->nullOnDelete();
        $table->unsignedBigInteger('credits')->default(0); $table->boolean('is_blocked')->default(false)->index(); $table->timestamp('last_seen_at')->nullable();
        $table->timestamp('email_verified_at')->nullable(); $table->rememberToken(); $table->timestamps();
    }); }
    public function down(): void { Schema::dropIfExists('users'); }
};
