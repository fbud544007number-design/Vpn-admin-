<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { public function up(): void { Schema::create('activity_logs',function(Blueprint $t):void{$t->id();$t->foreignId('actor_id')->nullable()->constrained('users')->nullOnDelete();$t->string('action')->index();$t->string('subject_type')->nullable();$t->unsignedBigInteger('subject_id')->nullable();$t->string('ip_address',45)->nullable();$t->json('details')->nullable();$t->timestamps();$t->index(['subject_type','subject_id']);}); } public function down():void{Schema::dropIfExists('activity_logs');} };
