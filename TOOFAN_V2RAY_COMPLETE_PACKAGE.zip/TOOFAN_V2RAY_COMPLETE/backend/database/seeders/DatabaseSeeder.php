<?php

namespace Database\Seeders;

use App\Models\Plan;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([['30 minutes',30,1],['60 minutes',60,1],['1 month',30*24*60,1],['2 months',60*24*60,2]] as [$name,$duration,$credits]) {
            Plan::firstOrCreate(['name'=>$name],['duration_minutes'=>$duration,'credit_cost'=>$credits,'is_active'=>true]);
        }
    }
}
