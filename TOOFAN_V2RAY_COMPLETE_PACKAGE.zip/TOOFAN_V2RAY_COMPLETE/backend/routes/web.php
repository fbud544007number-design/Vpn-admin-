<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PremiumController;
use App\Http\Controllers\ResellerController;
use App\Http\Controllers\LogController;
use App\Http\Controllers\ServerController;
use App\Http\Controllers\BulkController;
use Illuminate\Support\Facades\Route;

Route::get('/login', [AuthController::class, 'show'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:6,1')->name('login.submit');
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware(['auth'])->group(function (): void {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/premium', [PremiumController::class, 'index'])->name('premium.index');
    Route::post('/premium', [PremiumController::class, 'store'])->name('premium.store');
    Route::post('/premium/{account}/block', [PremiumController::class, 'toggleBlock'])->name('premium.block');
    Route::post('/premium/{account}/renew', [PremiumController::class, 'renew'])->name('premium.renew');
    Route::post('/premium/{account}/provision', [PremiumController::class, 'provision'])->middleware('role:super_admin')->name('premium.provision');
    Route::get('/resellers', [ResellerController::class, 'index'])->name('resellers.index');
    Route::post('/resellers', [ResellerController::class, 'store'])->name('resellers.store');
    Route::post('/resellers/transfer', [ResellerController::class, 'transfer'])->name('resellers.transfer');
    Route::post('/resellers/{user}/block', [ResellerController::class, 'toggleBlock'])->name('resellers.block');
    Route::get('/logs', [LogController::class, 'index'])->name('logs.index');
    Route::get('/bulk', [BulkController::class, 'index'])->name('bulk.index');
    Route::post('/bulk', [BulkController::class, 'store'])->name('bulk.store');
    Route::middleware('role:super_admin')->group(function (): void {
        Route::get('/servers', [ServerController::class, 'index'])->name('servers.index');
        Route::post('/servers', [ServerController::class, 'store'])->name('servers.store');
        Route::post('/servers/{server}/toggle', [ServerController::class, 'toggle'])->name('servers.toggle');
    });
});
