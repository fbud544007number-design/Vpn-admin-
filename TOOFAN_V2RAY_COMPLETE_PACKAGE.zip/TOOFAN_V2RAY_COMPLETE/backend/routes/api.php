<?php

use App\Http\Controllers\Api\MobileAuthController;
use App\Http\Controllers\Api\MobileDataController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function (): void {
    Route::post('/auth/login', [MobileAuthController::class, 'login'])->middleware('throttle:8,1');
    Route::post('/auth/activate', [MobileAuthController::class, 'activate'])->middleware('throttle:8,1');
    Route::middleware('api.token')->group(function (): void {
        Route::post('/auth/logout', [MobileAuthController::class, 'logout']);
        Route::get('/me', [MobileDataController::class, 'me']);
        Route::get('/servers', [MobileDataController::class, 'servers']);
        Route::get('/accounts', [MobileDataController::class, 'accounts']);
        Route::get('/accounts/{account}/config', [MobileDataController::class, 'config']);
    });
});
