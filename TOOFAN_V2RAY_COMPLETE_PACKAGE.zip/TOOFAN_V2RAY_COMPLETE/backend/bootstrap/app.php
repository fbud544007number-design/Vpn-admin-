<?php

use App\Http\Middleware\ApiTokenMiddleware;
use App\Http\Middleware\RoleMiddleware;
use App\Console\Commands\CreateAdmin;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(web: __DIR__.'/../routes/web.php', api: __DIR__.'/../routes/api.php', commands: __DIR__.'/../routes/console.php', health: '/up')
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'role' => RoleMiddleware::class,
            'api.token' => ApiTokenMiddleware::class,
        ]);
    })
    ->withCommands([CreateAdmin::class])
    ->withExceptions(function (Exceptions $exceptions): void {
        // Keep production errors in logs; never expose stack traces to users.
    })->create();
