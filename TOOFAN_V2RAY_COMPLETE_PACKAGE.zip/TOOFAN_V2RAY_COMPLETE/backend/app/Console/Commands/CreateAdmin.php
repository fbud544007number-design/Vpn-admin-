<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class CreateAdmin extends Command
{
    protected $signature='app:create-admin';
    protected $description='Create the first TOOFAN V2RAY super administrator';
    public function handle(): int
    {
        $username=$this->ask('Admin username');
        if (!$username || User::where('username',$username)->exists()) { $this->error('Username is empty or already used.'); return self::FAILURE; }
        $password=$this->secret('Password (minimum 14 characters)');
        if (!$password || strlen($password)<14) { $this->error('Password must contain at least 14 characters.'); return self::FAILURE; }
        User::create(['username'=>$username,'password'=>$password,'role'=>'super_admin','credits'=>0]);
        $this->info('Super Admin created. Keep the password in a password manager.');
        return self::SUCCESS;
    }
}
