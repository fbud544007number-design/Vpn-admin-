<?php

namespace App\Http\Middleware;

use App\Models\ApiToken;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiTokenMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $plain = $request->bearerToken();
        if (!$plain || strlen($plain) < 40) return response()->json(['message'=>'Unauthenticated'], 401);
        $token = ApiToken::with('user')->where('token_hash', hash('sha256', $plain))->first();
        if (!$token || !$token->user || $token->expires_at->isPast() || $token->user->is_blocked) return response()->json(['message'=>'Invalid or expired token'], 401);
        $token->forceFill(['last_used_at'=>now()])->save();
        $token->user->forceFill(['last_seen_at'=>now()])->save();
        $request->attributes->set('apiUser', $token->user);
        $request->attributes->set('apiToken', $token);
        return $next($request);
    }
}
