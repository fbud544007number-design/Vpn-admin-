<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\CreditTransaction;
use Illuminate\Http\Request;

class LogController extends Controller
{
    public function index(Request $request)
    {
        $actor=$request->user();
        $logs=ActivityLog::with('actor')->when($actor->isReseller(),fn($q)=>$q->where('actor_id',$actor->id))->latest()->paginate(30);
        $credits=CreditTransaction::with(['actor','sender','receiver'])->when($actor->isReseller(),fn($q)=>$q->where('actor_id',$actor->id)->orWhere('to_user_id',$actor->id))->latest()->paginate(30,['*'],'credits_page');
        return view('logs.index',compact('logs','credits'));
    }
}
