<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\User;
use App\Models\VpnAccount;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user->isAdmin() || $user->isReseller(), 403);
        $accountQuery = VpnAccount::query();
        $resellerQuery = User::where('role','reseller');
        if ($user->isReseller()) { $accountQuery->where('created_by',$user->id); $resellerQuery->where('parent_id',$user->id); }
        $accountCount=(clone $accountQuery)->count();
        $premiumCount=(clone $accountQuery)->where('created_via','premium')->count();
        $bulkCount=(clone $accountQuery)->where('created_via','bulk')->count();
        $resellerCount=(clone $resellerQuery)->count();
        $accounts = (clone $accountQuery)->with('user')->latest()->limit(8)->get();
        $logs = ActivityLog::with('actor')->when($user->isReseller(), fn($q)=>$q->where('actor_id',$user->id))->latest()->limit(10)->get();
        return view('dashboard', [
            'onlineCount'=>User::where('last_seen_at','>=',now()->subMinutes(2))->count(),
            'accountCount'=>$accountCount,
            'resellerCount'=>$resellerCount,
            'creditCount'=>$user->isAdmin() ? User::where('role','reseller')->sum('credits') : $user->credits,
            'premiumCount'=>$premiumCount,
            'bulkCount'=>$bulkCount,
            'resellerMixCount'=>$resellerCount, 'mixTotal'=>$premiumCount+$bulkCount+$resellerCount, 'accounts'=>$accounts, 'logs'=>$logs,
        ]);
    }
}
