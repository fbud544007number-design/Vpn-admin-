<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\CreditTransaction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rules\Password;

class ResellerController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user->isAdmin() || $user->isReseller(),403);
        $query = User::where('role','reseller')->with('parent');
        if ($user->isReseller()) $query->where('parent_id',$user->id);
        else $query->when(!$user->isAdmin(), fn($q)=>$q->whereRaw('1=0'));
        return view('resellers.index', ['resellers'=>$query->latest()->paginate(20)]);
    }

    public function store(Request $request)
    {
        $actor=$request->user();
        abort_unless($actor->isAdmin() || $actor->isReseller(),403);
        $data = $request->validate(['username'=>['required','alpha_dash','min:3','max:30','unique:users,username'],'password'=>['required',Password::min(12)],'credits'=>['required','integer','min:1','max:1000000']]);
        DB::transaction(function () use ($request,$data,$actor): void {
            $owner=User::whereKey($actor->id)->lockForUpdate()->firstOrFail();
            if (!$owner->isAdmin() && $owner->credits < $data['credits']) abort(422,'Insufficient credits to create this sub-reseller.');
            if (!$owner->isAdmin()) $owner->decrement('credits',$data['credits']);
            $reseller = User::create(['username'=>$data['username'],'password'=>$data['password'],'role'=>'reseller','parent_id'=>$owner->id,'credits'=>$data['credits']]);
            CreditTransaction::create(['actor_id'=>$owner->id,'from_user_id'=>$owner->isAdmin()?null:$owner->id,'to_user_id'=>$reseller->id,'amount'=>$data['credits'],'kind'=>$owner->isAdmin()?'admin_allocation':'subreseller_creation','note'=>'Initial credit allocation']);
            ActivityLog::create(['actor_id'=>$owner->id,'action'=>'reseller.created','subject_type'=>User::class,'subject_id'=>$reseller->id,'ip_address'=>$request->ip(),'details'=>['credits'=>$data['credits']]]);
        });
        return back()->with('success','Reseller created and credits allocated.');
    }

    public function transfer(Request $request)
    {
        $data=$request->validate(['username'=>['required','string'],'credits'=>['required','integer','min:1','max:1000000']]);
        $sender=$request->user();
        $receiver=User::where('username',$data['username'])->where('role','reseller')->firstOrFail();
        if (!$sender->isAdmin() && $receiver->parent_id !== $sender->id) abort(403);
        DB::transaction(function () use ($sender,$receiver,$data,$request): void {
            $target=User::whereKey($sender->id)->lockForUpdate()->firstOrFail();
            if (!$target->isAdmin() && $target->credits < $data['credits']) abort(422,'Insufficient credits.');
            if (!$target->isAdmin()) { $target->decrement('credits',$data['credits']); }
            $receiverLocked=User::whereKey($receiver->id)->lockForUpdate()->firstOrFail();
            $receiverLocked->increment('credits',$data['credits']);
            CreditTransaction::create(['actor_id'=>$sender->id,'from_user_id'=>$sender->isAdmin()?null:$sender->id,'to_user_id'=>$receiver->id,'amount'=>$data['credits'],'kind'=>$sender->isAdmin()?'admin_allocation':'reseller_transfer','note'=>'Credit transfer']);
            ActivityLog::create(['actor_id'=>$sender->id,'action'=>'credits.transferred','subject_type'=>User::class,'subject_id'=>$receiver->id,'ip_address'=>$request->ip(),'details'=>['amount'=>$data['credits']]]);
        });
        return back()->with('success','Credits transferred successfully.');
    }

    public function toggleBlock(Request $request, User $user)
    {
        abort_unless($user->role==='reseller',404);
        $actor=$request->user();
        abort_unless($actor->isAdmin() || $user->parent_id===$actor->id,403);
        $user->update(['is_blocked'=>!$user->is_blocked]);
        ActivityLog::create(['actor_id'=>$actor->id,'action'=>$user->is_blocked?'reseller.blocked':'reseller.unblocked','subject_type'=>User::class,'subject_id'=>$user->id,'ip_address'=>$request->ip()]);
        return back()->with('success','Reseller status updated.');
    }
}
