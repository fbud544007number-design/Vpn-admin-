<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function show() { return view('auth.login'); }

    public function login(Request $request)
    {
        $data = $request->validate(['username'=>['required','string','max:60'], 'password'=>['required','string','max:200']]);
        if (!Auth::attempt(['username'=>$data['username'],'password'=>$data['password'],'is_blocked'=>false])) {
            return back()->withErrors(['username'=>'Login information is incorrect or the account is blocked.'])->onlyInput('username');
        }
        if (!in_array(Auth::user()->role, ['super_admin','reseller'], true)) { Auth::logout(); return back()->withErrors(['username'=>'This account uses the mobile app only.']); }
        $request->session()->regenerate();
        $user = $request->user();
        $user->forceFill(['last_seen_at'=>now()])->save();
        ActivityLog::create(['actor_id'=>$user->id,'action'=>'login','ip_address'=>$request->ip(),'details'=>['guard'=>'web']]);
        return redirect()->intended(route('dashboard'));
    }

    public function logout(Request $request)
    {
        ActivityLog::create(['actor_id'=>$request->user()->id,'action'=>'logout','ip_address'=>$request->ip()]);
        Auth::logout(); $request->session()->invalidate(); $request->session()->regenerateToken();
        return redirect()->route('login');
    }
}
