<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\CreditTransaction;
use App\Models\Plan;
use App\Models\User;
use App\Models\VpnAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password;

class PremiumController extends Controller
{
    public function index(Request $request)
    {
        $actor=$request->user();
        abort_unless($actor->isAdmin() || $actor->isReseller(),403);
        $query=VpnAccount::with(['user','creator','plan'])->latest();
        if ($actor->isReseller()) $query->where('created_by',$actor->id);
        return view('premium.index',['accounts'=>$query->paginate(20),'plans'=>Plan::where('is_active',true)->get(),'plainPin'=>session('issued_pin')]);
    }

    public function store(Request $request)
    {
        $data=$request->validate(['username'=>['required','alpha_dash','min:3','max:30','unique:users,username'],'password'=>['required',Password::min(10)],'plan_id'=>['required','integer','exists:plans,id']]);
        $actor=$request->user(); $plan=Plan::where('is_active',true)->findOrFail($data['plan_id']);
        abort_if($actor->role==='customer',403);
        abort_if($plan->credit_cost < 1 || $plan->duration_minutes < 1,422,'Plan must have a positive credit cost and duration.');
        $pin=Str::upper(Str::random(4)).'-'.random_int(100000,999999);
        DB::transaction(function () use ($actor,$data,$plan,$pin,$request): void {
            $owner=User::whereKey($actor->id)->lockForUpdate()->firstOrFail();
            if (!$owner->isAdmin() && $owner->credits < $plan->credit_cost) abort(422,'Insufficient credits. Please request a top-up.');
            if (!$owner->isAdmin()) $owner->decrement('credits',$plan->credit_cost);
            $customer=User::create(['username'=>$data['username'],'password'=>$data['password'],'role'=>'customer','parent_id'=>$owner->isAdmin()?null:$owner->id,'credits'=>0]);
            $account=VpnAccount::create([
                'user_id'=>$customer->id,'created_by'=>$owner->id,'plan_id'=>$plan->id,'plan_name'=>$plan->name,'created_via'=>'premium',
                'credits_cost'=>$plan->credit_cost,'expires_at'=>now()->addMinutes($plan->duration_minutes),
                'status'=>'pending_server_provisioning','xray_client_id'=>(string) Str::uuid(), 'config_json'=>null,
            ]);
            $customer->forceFill(['activation_pin_hash'=>hash('sha256',$pin)])->save();
            CreditTransaction::create(['actor_id'=>$owner->id,'from_user_id'=>$owner->isAdmin()?null:$owner->id,'to_user_id'=>$customer->id,'amount'=>$plan->credit_cost,'kind'=>'account_creation','reference_type'=>VpnAccount::class,'reference_id'=>$account->id,'note'=>'Plan: '.$plan->name]);
            ActivityLog::create(['actor_id'=>$owner->id,'action'=>'vpn_account.created','subject_type'=>VpnAccount::class,'subject_id'=>$account->id,'ip_address'=>$request->ip(),'details'=>['plan'=>$plan->name,'cost'=>$plan->credit_cost,'server_provisioning'=>'pending']]);
        });
        return redirect()->route('premium.index')->with('success','Account record created. Xray server provisioning is still pending.')->with('issued_pin',$pin);
    }
    public function provision(Request $request, VpnAccount $account)
    {
        $data=$request->validate(['config_json'=>['required','string','json','max:65000']]);
        abort_if($account->status==='blocked',422,'Unblock this account before provisioning.');
        abort_if($account->expires_at->isPast(),422,'This account has expired. Renew it first.');
        $config=json_decode($data['config_json'],true,512,JSON_THROW_ON_ERROR);
        abort_unless(is_array($config) && !empty($config['outbounds']) && is_array($config['outbounds']),422,'The Xray JSON must contain at least one outbound.');
        $account->update(['config_json'=>$config,'status'=>'active']);
        ActivityLog::create(['actor_id'=>$request->user()->id,'action'=>'vpn_account.manually_provisioned','subject_type'=>VpnAccount::class,'subject_id'=>$account->id,'ip_address'=>$request->ip(),'details'=>['mode'=>'manual_config_upload']]);
        return back()->with('success','Client config stored encrypted and API access activated. Confirm that the matching user is already configured on the Xray server.');
    }

    public function toggleBlock(Request $request, VpnAccount $account)
    {
        $actor=$request->user();
        abort_unless($actor->isAdmin() || $account->created_by===$actor->id,403);
        if ($account->status==='blocked') {
            $account->update(['status'=>$account->expires_at->isPast()?'expired':'pending_server_provisioning']);
        } else {
            $account->update(['status'=>'blocked']);
        }
        ActivityLog::create(['actor_id'=>$actor->id,'action'=>$account->status==='blocked'?'vpn_account.blocked':'vpn_account.unblocked','subject_type'=>VpnAccount::class,'subject_id'=>$account->id,'ip_address'=>$request->ip()]);
        return back()->with('success','Local account status updated. Xray server revocation/sync still requires the server adapter.');
    }

    public function renew(Request $request, VpnAccount $account)
    {
        $actor=$request->user();
        abort_unless($actor->isAdmin() || $account->created_by===$actor->id,403);
        abort_if($account->status==='blocked',422,'Unblock the account before renewing.');
        $data=$request->validate(['plan_id'=>['required','integer','exists:plans,id']]);
        $plan=Plan::where('is_active',true)->findOrFail($data['plan_id']);
        abort_if($plan->credit_cost < 1 || $plan->duration_minutes < 1,422,'Plan must have a positive credit cost and duration.');
        DB::transaction(function () use ($actor,$account,$plan,$request): void {
            $owner=User::whereKey($actor->id)->lockForUpdate()->firstOrFail();
            if (!$owner->isAdmin() && $owner->credits < $plan->credit_cost) abort(422,'Insufficient credits for renewal.');
            if (!$owner->isAdmin()) $owner->decrement('credits',$plan->credit_cost);
            $locked=VpnAccount::whereKey($account->id)->lockForUpdate()->firstOrFail();
            $base=$locked->expires_at->isPast()?now():$locked->expires_at->copy();
            $locked->update(['expires_at'=>$base->addMinutes($plan->duration_minutes),'status'=>'pending_server_provisioning']);
            CreditTransaction::create(['actor_id'=>$owner->id,'from_user_id'=>$owner->isAdmin()?null:$owner->id,'to_user_id'=>$locked->user_id,'amount'=>$plan->credit_cost,'kind'=>'account_renewal','reference_type'=>VpnAccount::class,'reference_id'=>$locked->id,'note'=>'Renewal: '.$plan->name]);
            ActivityLog::create(['actor_id'=>$owner->id,'action'=>'vpn_account.renewed','subject_type'=>VpnAccount::class,'subject_id'=>$locked->id,'ip_address'=>$request->ip(),'details'=>['plan'=>$plan->name,'credits'=>$plan->credit_cost]]);
        });
        return back()->with('success','Account expiry updated. Xray expiry synchronization is still pending.');
    }

}
