<?php
namespace App\Http\Controllers;
use App\Models\ActivityLog;
use App\Models\CreditTransaction;
use App\Models\Plan;
use App\Models\User;
use App\Models\VpnAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class BulkController extends Controller
{
 public function index(Request $request){$actor=$request->user();abort_unless($actor->isAdmin()||$actor->isReseller(),403);return view('bulk.index',['plans'=>Plan::where('is_active',true)->get()]);}
 public function store(Request $request){$d=$request->validate(['prefix'=>['required','alpha_dash','min:2','max:18'],'quantity'=>['required','integer','between:1,50'],'plan_id'=>['required','integer','exists:plans,id']]);$actor=$request->user();$plan=Plan::where('is_active',true)->findOrFail($d['plan_id']);abort_if($plan->credit_cost<1||$plan->duration_minutes<1,422,'Plan must have a positive credit cost and duration.');$total=$plan->credit_cost*$d['quantity'];$created=[];
  DB::transaction(function()use($actor,$d,$plan,$total,$request,&$created){$owner=User::whereKey($actor->id)->lockForUpdate()->firstOrFail();if(!$owner->isAdmin()&&$owner->credits<$total)abort(422,'Insufficient credits for this bulk operation.');if(!$owner->isAdmin())$owner->decrement('credits',$total);
   for($i=0;$i<$d['quantity'];$i++){do{$username=$d['prefix'].'_'.Str::lower(Str::random(5));}while(User::where('username',$username)->exists());$password=Str::random(16);$pin=Str::upper(Str::random(3)).'-'.random_int(10000,99999);$customer=User::create(['username'=>$username,'password'=>$password,'role'=>'customer','parent_id'=>$owner->isAdmin()?null:$owner->id,'credits'=>0]);$customer->forceFill(['activation_pin_hash'=>hash('sha256',$pin)])->save();$account=VpnAccount::create(['user_id'=>$customer->id,'created_by'=>$owner->id,'plan_id'=>$plan->id,'plan_name'=>$plan->name,'created_via'=>'bulk','credits_cost'=>$plan->credit_cost,'expires_at'=>now()->addMinutes($plan->duration_minutes),'status'=>'pending_server_provisioning','xray_client_id'=>(string)Str::uuid()]);$created[]=['username'=>$username,'password'=>$password,'pin'=>$pin,'account_id'=>$account->id];}
   CreditTransaction::create(['actor_id'=>$owner->id,'from_user_id'=>$owner->isAdmin()?null:$owner->id,'amount'=>$total,'kind'=>'bulk_account_creation','note'=>$d['quantity'].' x '.$plan->name]);ActivityLog::create(['actor_id'=>$owner->id,'action'=>'vpn_accounts.bulk_created','ip_address'=>$request->ip(),'details'=>['quantity'=>$d['quantity'],'credits'=>$total,'plan'=>$plan->name]]);
  });
  return redirect()->route('bulk.index')->with('success','Bulk records created. Xray provisioning remains pending.')->with('bulk_credentials',$created);
 }
}
