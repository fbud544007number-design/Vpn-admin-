<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\VpnAccount;
use App\Models\VpnServer;
use Illuminate\Http\Request;

class MobileDataController extends Controller
{
    public function me(Request $request)
    {
        $user=$request->attributes->get('apiUser');
        $account=VpnAccount::where('user_id',$user->id)->latest()->first();
        return response()->json(['user'=>['username'=>$user->username,'role'=>$user->role,'credits'=>$user->credits],'account'=>$account?['status'=>$account->status,'expires_at'=>$account->expires_at?->toIso8601String(),'expired'=>$account->expires_at?->isPast()]:null]);
    }
    public function servers()
    {
        return response()->json(['servers'=>VpnServer::where('is_active',true)->orderBy('sort_order')->get(['id','name','country','host','port','protocol'])]);
    }
    public function accounts(Request $request)
    {
        $user=$request->attributes->get('apiUser');
        return response()->json(['accounts'=>VpnAccount::where('user_id',$user->id)->latest()->get(['id','plan_name','status','expires_at'])]);
    }
    public function config(Request $request, VpnAccount $account)
    {
        $user=$request->attributes->get('apiUser');
        abort_unless($account->user_id===$user->id,404);
        if ($account->status!=='active' || !$account->config_json || $account->expires_at?->isPast()) return response()->json(['message'=>'VPN configuration is not provisioned or account has expired.'],409);
        return response()->json(['config'=>$account->config_json]);
    }
}
