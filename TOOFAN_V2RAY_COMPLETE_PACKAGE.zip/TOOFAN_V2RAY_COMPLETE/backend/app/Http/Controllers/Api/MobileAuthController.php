<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Models\ApiToken;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class MobileAuthController extends Controller
{
    public function login(Request $request)
    {
        $data=$request->validate(['username'=>['required','string','max:60'],'password'=>['required','string','max:200']]);
        $user=User::where('username',$data['username'])->first();
        if (!$user || $user->is_blocked || $user->activation_pin_hash || !Hash::check($data['password'],$user->password)) return response()->json(['message'=>'Invalid credentials or blocked account'],401);
        $plain=Str::random(72);
        ApiToken::create(['user_id'=>$user->id,'token_hash'=>hash('sha256',$plain),'expires_at'=>now()->addDays(30)]);
        $user->forceFill(['last_seen_at'=>now()])->save();
        ActivityLog::create(['actor_id'=>$user->id,'action'=>'api.login','ip_address'=>$request->ip()]);
        return response()->json(['token'=>$plain,'token_type'=>'Bearer','expires_at'=>now()->addDays(30)->toIso8601String(),'user'=>['id'=>$user->id,'username'=>$user->username,'role'=>$user->role]]);
    }


    public function activate(Request $request)
    {
        $data=$request->validate(['username'=>['required','string','max:60'],'pin'=>['required','string','max:32'],'new_password'=>['required',\Illuminate\Validation\Rules\Password::min(10)]]);
        $user=User::where('username',$data['username'])->first();
        if (!$user || $user->is_blocked || !$user->activation_pin_hash || !hash_equals($user->activation_pin_hash,hash('sha256',$data['pin']))) return response()->json(['message'=>'Invalid or already-used activation PIN'],422);
        $user->forceFill(['password'=>$data['new_password'],'activation_pin_hash'=>null,'last_seen_at'=>now()])->save();
        $plain=Str::random(72);
        ApiToken::create(['user_id'=>$user->id,'token_hash'=>hash('sha256',$plain),'expires_at'=>now()->addDays(30)]);
        ActivityLog::create(['actor_id'=>$user->id,'action'=>'api.account_activated','ip_address'=>$request->ip()]);
        return response()->json(['token'=>$plain,'token_type'=>'Bearer','expires_at'=>now()->addDays(30)->toIso8601String(),'user'=>['id'=>$user->id,'username'=>$user->username,'role'=>$user->role]]);
    }

    public function logout(Request $request)
    {
        $request->attributes->get('apiToken')->delete();
        return response()->json(['message'=>'Logged out']);
    }
}
