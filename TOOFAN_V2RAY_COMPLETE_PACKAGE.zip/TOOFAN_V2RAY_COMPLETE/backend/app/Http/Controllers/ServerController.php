<?php
namespace App\Http\Controllers;
use App\Models\ActivityLog;
use App\Models\VpnServer;
use Illuminate\Http\Request;
class ServerController extends Controller
{
 public function index(){return view('servers.index',['servers'=>VpnServer::orderBy('sort_order')->paginate(20)]);}
 public function store(Request $request){$d=$request->validate(['name'=>['required','string','max:80'],'country'=>['required','string','max:80'],'host'=>['required','string','max:255'],'port'=>['required','integer','between:1,65535'],'protocol'=>['required','in:VLESS,VMess,Trojan'],'is_active'=>['nullable','boolean']]);$d['is_active']=$request->boolean('is_active');$server=VpnServer::create($d);ActivityLog::create(['actor_id'=>$request->user()->id,'action'=>'server.created','subject_type'=>VpnServer::class,'subject_id'=>$server->id,'ip_address'=>$request->ip()]);return back()->with('success','Server record saved. Validate its Xray service and TLS configuration before enabling it for customers.');}
 public function toggle(Request $request,VpnServer $server){$server->update(['is_active'=>!$server->is_active]);ActivityLog::create(['actor_id'=>$request->user()->id,'action'=>'server.toggled','subject_type'=>VpnServer::class,'subject_id'=>$server->id,'ip_address'=>$request->ip()]);return back()->with('success','Server visibility updated. This does not provision or test Xray.');}
}
