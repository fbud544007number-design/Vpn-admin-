<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VpnServer extends Model
{
    protected $fillable = ['name','country','host','port','protocol','is_active','sort_order'];
    protected function casts(): array { return ['port'=>'integer','is_active'=>'boolean','sort_order'=>'integer']; }
}
