<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    protected $fillable = ['name','duration_minutes','credit_cost','is_active'];
    protected function casts(): array { return ['duration_minutes'=>'integer','credit_cost'=>'integer','is_active'=>'boolean']; }
}
