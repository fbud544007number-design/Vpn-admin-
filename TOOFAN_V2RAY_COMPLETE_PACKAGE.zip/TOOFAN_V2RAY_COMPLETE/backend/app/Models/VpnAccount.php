<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VpnAccount extends Model
{
    protected $fillable = ['user_id','created_by','plan_id','plan_name','created_via','credits_cost','expires_at','status','xray_client_id','config_json','last_connected_at'];
    protected function casts(): array { return ['expires_at'=>'datetime','last_connected_at'=>'datetime','credits_cost'=>'integer','config_json'=>'encrypted:array']; }
    public function user() { return $this->belongsTo(User::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function plan() { return $this->belongsTo(Plan::class); }
}
