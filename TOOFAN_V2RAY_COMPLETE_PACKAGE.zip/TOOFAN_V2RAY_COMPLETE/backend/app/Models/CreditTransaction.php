<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreditTransaction extends Model
{
    protected $fillable = ['actor_id','from_user_id','to_user_id','amount','kind','reference_type','reference_id','note'];
    protected function casts(): array { return ['amount'=>'integer']; }
    public function actor() { return $this->belongsTo(User::class, 'actor_id'); }
    public function sender() { return $this->belongsTo(User::class, 'from_user_id'); }
    public function receiver() { return $this->belongsTo(User::class, 'to_user_id'); }
}
