<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = ['username', 'email', 'password', 'role', 'parent_id', 'credits', 'is_blocked', 'last_seen_at'];
    protected $hidden = ['password', 'remember_token', 'activation_pin_hash'];
    protected function casts(): array { return ['email_verified_at' => 'datetime', 'password' => 'hashed', 'is_blocked' => 'boolean', 'last_seen_at' => 'datetime', 'credits' => 'integer']; }

    public function parent() { return $this->belongsTo(self::class, 'parent_id'); }
    public function children() { return $this->hasMany(self::class, 'parent_id'); }
    public function vpnAccounts() { return $this->hasMany(VpnAccount::class, 'user_id'); }
    public function apiTokens() { return $this->hasMany(ApiToken::class); }
    public function isAdmin(): bool { return $this->role === 'super_admin'; }
    public function isReseller(): bool { return $this->role === 'reseller'; }
}
