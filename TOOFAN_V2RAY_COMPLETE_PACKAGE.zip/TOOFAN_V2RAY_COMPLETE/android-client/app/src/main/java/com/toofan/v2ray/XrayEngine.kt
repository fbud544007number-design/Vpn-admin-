package com.toofan.v2ray

/**
 * Adapter boundary for the native Xray engine.
 * The libXray AAR/JNI binding is intentionally not fabricated or bundled in this starter.
 * Replace this implementation after building the official libXray Android artifact and
 * implementing socket protection, VPN TUN routing and lifecycle handling.
 */
interface XrayEngine {
    fun isAvailable(): Boolean
    fun start(xrayJson: String): Result<Unit>
    fun stop(): Result<Unit>
}

class XrayEngineNotInstalled : XrayEngine {
    override fun isAvailable() = false
    override fun start(xrayJson: String) = Result.failure<Unit>(IllegalStateException("Native Xray core is not installed in this build."))
    override fun stop() = Result.failure<Unit>(IllegalStateException("Native Xray core is not installed in this build."))
}
