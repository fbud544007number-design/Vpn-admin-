package com.toofan.v2ray

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ApiClient(private val baseUrl: String, private val tokenStore: SecureTokenStore) {
    private fun request(path: String, method: String = "GET", body: JSONObject? = null): JSONObject {
        require(baseUrl.startsWith("https://")) { "API URL must use HTTPS" }
        val connection = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 12000; readTimeout = 12000
            setRequestProperty("Accept", "application/json")
            tokenStore.read()?.let { setRequestProperty("Authorization", "Bearer $it") }
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json") }
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val json = JSONObject(text)
            if (code !in 200..299) throw IllegalStateException(json.optString("message", "HTTP $code"))
            return json
        } finally { connection.disconnect() }
    }

    fun login(username: String, password: String): JSONObject {
        val result = request("/auth/login", "POST", JSONObject().put("username", username).put("password", password))
        tokenStore.save(result.getString("token")); return result
    }
    fun activate(username: String, pin: String, newPassword: String): JSONObject {
        val result = request("/auth/activate", "POST", JSONObject().put("username", username).put("pin", pin).put("new_password", newPassword))
        tokenStore.save(result.getString("token")); return result
    }
    fun me() = request("/me")
    fun servers() = request("/servers")
    fun accounts() = request("/accounts")
    fun accountConfig(accountId: Long) = request("/accounts/$accountId/config")
    fun logout() { try { request("/auth/logout", "POST", JSONObject()) } finally { tokenStore.clear() } }
}
