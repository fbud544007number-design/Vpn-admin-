package com.toofan.v2ray

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var tokenStore: SecureTokenStore
    private lateinit var api: ApiClient
    private lateinit var container: LinearLayout
    private var selectedServer: String? = null
    private val cyan = Color.rgb(66, 209, 229)
    private val panel = Color.rgb(27, 34, 36)
    private val muted = Color.rgb(174, 185, 189)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 21, 22); window.navigationBarColor = Color.rgb(16, 21, 22)
        tokenStore = SecureTokenStore(this); api = ApiClient(BuildConfig.API_BASE_URL, tokenStore)
        if (tokenStore.read() != null) loadHome() else showLogin()
    }
    private fun root(): LinearLayout {
        val scroll = ScrollView(this)
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 30); setBackgroundColor(Color.rgb(16,21,22)) }
        scroll.addView(container); setContentView(scroll); return container
    }
    private fun text(value: String, size: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(2, 8, 2, 8)
    }
    private fun field(hint: String, password: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint; setHintTextColor(muted); setTextColor(Color.WHITE); textSize = 16f; setSingleLine(true)
        setPadding(18, 12, 18, 12); setBackgroundColor(panel)
        if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; setTextColor(Color.rgb(7,52,59)); setBackgroundColor(cyan); setOnClickListener { action() }
    }
    private fun logo() {
        try { val bitmap = assets.open("toofan-v2ray-logo.jpg").use { BitmapFactory.decodeStream(it) }; val image = ImageView(this).apply { setImageBitmap(bitmap); scaleType = ImageView.ScaleType.FIT_CENTER }
            container.addView(image, LinearLayout.LayoutParams(190,190).apply { gravity = Gravity.CENTER; bottomMargin = 6 })
            val wordmark = assets.open("toofan-v2ray-wordmark.jpg").use { BitmapFactory.decodeStream(it) }
            container.addView(ImageView(this).apply { setImageBitmap(wordmark); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(-1, 90).apply { bottomMargin = 5 })
        } catch (_: Exception) { }
        container.addView(text("VIRTUAL PRIVATE NETWORK", 12f, muted).apply { gravity = Gravity.CENTER })
    }
    private fun showLogin(message: String? = null) {
        root(); logo(); container.addView(text("Customer / Reseller Login",20f,Color.WHITE,true))
        val username = field("Username"); val password = field("Password / New password", true); val pin = field("First-time activation PIN")
        container.addView(username); container.addView(password); container.addView(pin)
        message?.let { container.addView(text(it,14f,Color.rgb(255,160,160))) }
        container.addView(button("LOGIN") {
            val u=username.text.toString().trim(); val p=password.text.toString()
            if (u.isBlank() || p.isBlank()) { showLogin("Enter username and password."); return@button }
            container.addView(text("Signing in…",14f,muted))
            executor.execute { try { api.login(u,p); runOnUiThread { loadHome() } } catch(e:Exception) { runOnUiThread { showLogin(e.message ?: "Login failed") } } }
        })
        container.addView(button("ACTIVATE WITH PIN") {
            val u=username.text.toString().trim(); val code=pin.text.toString().trim(); val newPassword=password.text.toString()
            if (u.isBlank() || code.isBlank() || newPassword.length < 10) { showLogin("Enter username, one-time PIN and a password of at least 10 characters."); return@button }
            container.addView(text("Activating account…",14f,muted))
            executor.execute { try { api.activate(u,code,newPassword); runOnUiThread { loadHome() } } catch(e:Exception) { runOnUiThread { showLogin(e.message ?: "Activation failed") } } }
        })
        container.addView(text("First-time customers: use the one-time PIN supplied by your reseller. The API must be hosted over HTTPS.",12f,muted))
        container.addView(text("API endpoint: ${BuildConfig.API_BASE_URL}",11f,muted))
    }
    private fun loadHome() {
        root(); logo(); container.addView(text("Account & Server",21f,Color.WHITE,true))
        val accountText=text("Loading account…",15f,muted); container.addView(accountText)
        val serversBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,8,0,8) }; container.addView(serversBox)
        val connect=button("CONNECT") { Toast.makeText(this,"Xray native core is not linked in this starter build. No VPN tunnel was started.",Toast.LENGTH_LONG).show() }
        connect.isEnabled=false; connect.alpha=0.55f; container.addView(connect)
        container.addView(text("Connection: Not connected",14f,muted))
        container.addView(text("A valid Wi-Fi/mobile data connection is required. VPN does not create free SIM data or bypass operator limits.",13f,muted))
        container.addView(button("LOGOUT") { executor.execute { try { api.logout() } catch (_:Exception) { tokenStore.clear() }; runOnUiThread { showLogin() } } })
        executor.execute {
            try {
                val me=api.me(); val usr=me.optJSONObject("user"); val acc=me.optJSONObject("account")
                val txt="User: ${usr?.optString("username")}  •  Role: ${usr?.optString("role")}  •  Credits: ${usr?.optInt("credits") ?: 0}\nAccount: ${acc?.optString("status") ?: "Not found"}\nExpiry: ${acc?.optString("expires_at") ?: "—"}"
                val servers=api.servers().optJSONArray("servers") ?: JSONArray()
                runOnUiThread {
                    accountText.text=txt
                    if(servers.length()==0) serversBox.addView(text("No active server is published yet.",14f,muted))
                    for(i in 0 until servers.length()) { val s=servers.getJSONObject(i); val title="${s.optString("name")} · ${s.optString("country")}\n${s.optString("host")}:${s.optInt("port")} · ${s.optString("protocol")}"; val b=button(title){selectedServer=s.optString("id");Toast.makeText(this,"Selected ${s.optString("name")}",Toast.LENGTH_SHORT).show()};serversBox.addView(b) }
                }
            } catch(e:Exception) { runOnUiThread { accountText.text="Could not load API data: ${e.message}" } }
        }
    }
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
