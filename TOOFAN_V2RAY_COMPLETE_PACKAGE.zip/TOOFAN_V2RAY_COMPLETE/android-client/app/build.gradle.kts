plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.toofan.v2ray"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.toofan.v2ray"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0-starter"
        val endpoint = (project.findProperty("API_BASE_URL") as String?) ?: "https://your-domain.example/api/v1"
        buildConfigField("String", "API_BASE_URL", "\"$endpoint\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
